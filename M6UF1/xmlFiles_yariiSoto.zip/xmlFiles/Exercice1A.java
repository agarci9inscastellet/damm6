package xmlFiles;


import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

/*
 * Exercise 1.
 * 
 * From the Person class, which will have information about name and age of people, performs the following tasks:
 * 
 * a) Create a file named persones.bin that stores several objects Person in binary format (must store each person's name and age, not the whole object).
 * 
 * b) Make a program that reads the above file and creates an XML document appropriate using DOM.
 * 
 * c) Implement a method that allows the section's XML document to be read above and rebuild a list of Person objects.
 * 
 * d) Create an XSL template to create an HTML presentation of the XML file generated
 * 
 * e) Use SAX to view the contents of the file we created a the previous exercise.
 * */
/**
 * 
 * @author Yarií Soto
 * @version v1, 27 October 2023
 */
public class Exercice1A {
	public static void main(String[] args) {
		// a) Create a file named persones.bin that stores several objects Person in binary format (must store each person's name and age, not the whole object).
		List<Person> people = new ArrayList<>();
        people.add(new Person("Pepe", 30));
        people.add(new Person("Rosa", 25));
        people.add(new Person("Joana", 35));

        try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream("persones.bin"))) {
            for (Person person : people) {
                outputStream.writeObject(person.getName());
                outputStream.writeInt(person.getAge());
            }
            System.out.println("Objects written to persones.bin");
        } catch (IOException e) {
            System.err.println("ERROR: "+e.getMessage());
        }
    }

}
