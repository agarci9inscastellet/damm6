package xmlFiles;


import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * 
 * @author yarii
 *
 */
public class PeopleHandler extends DefaultHandler{
	private StringBuilder value;

	/**
	 * PeopleHandler constructor
	 */
	public PeopleHandler() {
		this.value = new StringBuilder();
	}
	
	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		this.value.setLength(0);
		if(qName.equals("people")) {
			System.out.println("People list:\n");
		}
	}

	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		this.value.append(ch, start, length);
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		switch (qName) {
        case "person":
            System.out.println("");
            break;
        case "name":
            System.out.println("Name: " + this.value.toString());
            break;
        case "age":
            System.out.println("Age: " + this.value.toString());
            break;
		}
	}
}
