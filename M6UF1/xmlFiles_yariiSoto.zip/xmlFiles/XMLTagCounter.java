package xmlFiles;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * @author Yarií Soto
 * @version v1, 4 November 2023
 *
 */
public class XMLTagCounter extends DefaultHandler{
	private Map<String, Integer> tagCount;
	
	public XMLTagCounter() {
		tagCount=new HashMap<>();
	}
	
	/**
	 * Method to count tags.
	 * @param file - a XML file.
	 */
	public void countTags(String file) {
		try {
			File inputFile = new File(file);
			SAXParserFactory saxFactory = SAXParserFactory.newInstance();
			SAXParser saxParser = saxFactory.newSAXParser();
			
			saxParser.parse(inputFile, this);
			
			for(Map.Entry<String, Integer> entry : tagCount.entrySet()) {
				System.out.println("Tag: " + entry.getKey() + " - Count: " + entry.getValue());
			}
		} catch (ParserConfigurationException | SAXException | IOException e) {
			System.out.println(e.getMessage());
		}
	}
	
	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		tagCount.put(qName, tagCount.getOrDefault(qName, 0)+1);
	}
}
