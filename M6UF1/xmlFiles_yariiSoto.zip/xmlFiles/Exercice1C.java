package xmlFiles;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

//c) Implement a method that allows the section's XML document to be read above and rebuild a list of Person objects.

/**
 * @author Yarií Soto
 * @version v1, 27 October 2023
 */
public class Exercice1C {

	public static void main(String[] args) {
		List<Person> people =new ArrayList<>();
		
		try {
			people=readXml("persones.xml");
		} catch (ParserConfigurationException | SAXException | IOException e) {
			System.err.println("ERROR: "+e.getMessage());
		}
		
		//System.out.println(people.toString());
	}
	
	/**
	 * Read a XML document
	 * @param file - Document location
	 * @return A Person ArrayList
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 */
	public static List<Person> readXml(String file) throws ParserConfigurationException, SAXException, IOException {
		List<Person> people =new ArrayList<>();
		File xmlFile = new File(file);
		
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = dbFactory.newDocumentBuilder();
		Document xmlDoc = builder.parse(xmlFile);
		
		xmlDoc.getDocumentElement().normalize();
		
		NodeList peopleList = xmlDoc.getElementsByTagName("person");
		
		for(int i=0;i<peopleList.getLength();i++) {
			Node person=peopleList.item(i);
			
			if(person.getNodeType()==Node.ELEMENT_NODE) {
				Element element = (Element) person;
				
				String name = element.getElementsByTagName("name").item(0).getTextContent();
				int age = Integer.parseInt(element.getElementsByTagName("age").item(0).getTextContent());
				
				people.add(new Person(name,age));
			}
		}
		
		return people;
	}
}
