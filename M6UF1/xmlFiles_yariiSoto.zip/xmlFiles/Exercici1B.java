package xmlFiles;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.PrintWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * 
 * @author Yarií Soto
 * @version v1, 31 October 2023
 */
public class Exercici1B {
	public static void main(String[] args) {
		 //b) Make a program that reads the above file and creates an XML document appropriate using DOM.
		try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream("persones.bin"))) {
			Document doc;
			
			DocumentBuilderFactory fact = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = fact.newDocumentBuilder();
			doc=builder.newDocument();
            
            Element people = doc.createElement("people");
    		doc.appendChild(people);
    		
            while (true) {
                try {
                	String inputName = (String) inputStream.readObject();
	                int inputAge = inputStream.readInt();
	                
	                Element person = doc.createElement("person");
	                people.appendChild(person);
	        		
	        		Element name = doc.createElement("name");
	        		name.appendChild(doc.createTextNode(inputName));
	        		person.appendChild(name);
	        		
	        		Element age = doc.createElement("age");
	        		age.appendChild(doc.createTextNode(Integer.toString(inputAge)));
	        		person.appendChild(age);
	                
                } catch (EOFException e) {
                    break;
                }
            }
            
            generateXml(doc);
            System.out.println("XML file generated successfully.");
        } catch (IOException | ClassNotFoundException e) {
            System.err.println(e.getMessage());
        } catch (ParserConfigurationException e) {
        	 System.err.println(e.getMessage());
		} catch (TransformerException e) {
			System.err.println(e.getMessage());
		}
		
	}
	
	/**
	 * Generate a XML document.
	 * @param doc - a DOC document
	 * @throws TransformerException
	 * @throws IOException
	 */
	public static void generateXml(Document doc) throws TransformerException, IOException {
		TransformerFactory fact = TransformerFactory.newInstance();
		Transformer trans = fact.newTransformer();
		
		Source source = new DOMSource(doc);
		
		File file = new File("persones.xml");
		FileWriter fw = new FileWriter(file);
		PrintWriter pw = new PrintWriter(fw);
		Result result = new StreamResult (pw);
		
		trans.transform(source,result);
	}
}
