package xmlFiles;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class DOMgenerator {
	private Document doc;

	public DOMgenerator() throws ParserConfigurationException {
		DocumentBuilderFactory fact = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = fact.newDocumentBuilder();
		
		doc=builder.newDocument();
	}
	
	public void generateDoc(String rootElement, String firstElement, String secElement, String thirdElement) {
		Element element = doc.createElement(rootElement);
		doc.appendChild(element);
		
		Element element1 = doc.createElement(firstElement);
		element.appendChild(element1);
		
		Element element2 = doc.createElement(secElement);
		element1.appendChild(element2);
		
		Element element3 = doc.createElement(thirdElement);
		element1.appendChild(element3);
	}
	
	public void generateXml() throws TransformerException, IOException {
		TransformerFactory fact = TransformerFactory.newInstance();
		Transformer trans = fact.newTransformer();
		
		Source source = new DOMSource(doc);
		
		File file = new File("persones.xml");
		FileWriter fw = new FileWriter(file);
		PrintWriter pw = new PrintWriter(fw);
		Result result = new StreamResult (pw);
		
		trans.transform(source,result);
	}
	
	
}
