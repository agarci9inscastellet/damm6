package xmlFiles;

/*
 * Exercise 2. Counting elements
 * 
 * This program will receive an XML file name per parameter, from which, using SAX, it will count and display how many tags of each types appear in the file.
 * */
/**
 * 
 * @author Yarií Soto
 * @version v1, 4 November 2023
 *
 */
public class Exercice2 {
	public static void main(String[] args) {
		if(args.length==0) {
			System.out.println("No arguments entered");
		}else {
			String fileName = args[0];
            XMLTagCounter handler = new XMLTagCounter();
            
            System.out.println("Tag counting:");
            handler.countTags(fileName);
		}
	}
}
