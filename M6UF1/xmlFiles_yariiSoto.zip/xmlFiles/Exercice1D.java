package xmlFiles;

import javax.xml.transform.*;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.File;

/*
 * d) Create an XSL template to create an HTML presentation of the XML file generated
 * */
/**
 * @author Yarií Soto
 * @version v1, 27 October 2023
 */
public class Exercice1D {

	public static void main(String[] args) {
		try {
            //Specify the paths to the XML and XSL files
            String xmlFilePath = "persones.xml";
            String xslFilePath = "template.xsl";

            //Specify the path for the output HTML file
            String outputFilePath = "output.html";

            //Create a TransformerFactory
            TransformerFactory transformerFactory = TransformerFactory.newInstance();

            //Create a Transformer from the XSL file
            Source xslSource = new StreamSource(new File(xslFilePath));
            Transformer transformer = transformerFactory.newTransformer(xslSource);

            //Create a Source from the XML file
            Source xmlSource = new StreamSource(new File(xmlFilePath));

            //Create a Result to hold the transformed content
            Result result = new StreamResult(new File(outputFilePath));

            //Apply the transformation
            transformer.transform(xmlSource, result);

            System.out.println("Transformation successful. HTML output saved to " + outputFilePath);

        } catch (TransformerException e) {
            System.err.println("Transformation error: " + e.getMessage());
        }

	}

}
