package xmlFiles;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

//e) Use SAX to view the contents of the file we created at the previous exercise.
/**
 * @author Yarií Soto
 * @version v1, 27 October 2023
 * 
 */
public class Exercice1E {

	public static void main(String[] args) {
		try {
			File inputFile = new File("persones.xml");
			saxXmlReader(inputFile);
		} catch (ParserConfigurationException | SAXException e) {
			System.out.println(e.getMessage());
		}
	}
	
	public static void saxXmlReader(File file) throws ParserConfigurationException, SAXException {
		try {
			SAXParserFactory saxFactory = SAXParserFactory.newInstance();
			SAXParser saxParser = saxFactory.newSAXParser();
			PeopleHandler handler = new PeopleHandler();
			
			saxParser.parse(file,handler);
			
			
		} catch (ParserConfigurationException | SAXException | IOException e) {
			System.err.println(e.getMessage());
		}
	}

}
