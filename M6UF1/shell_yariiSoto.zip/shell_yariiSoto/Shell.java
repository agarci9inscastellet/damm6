package shell;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.io.Serializable;
import java.util.Scanner;

/**
 * Shell class
 * @author Yarií Soto
 * @version v1, 13 October 2023
 */
public class Shell implements Serializable{
	private static final long serialVersionUID = 1L;
	private Session session;
	
	public Shell(Session session) {
		this.session = session;
	}
	
	public void startShell() {
		Scanner input = new Scanner(System.in);
		
		System.out.print(session.getUsername() + "> ");
        String command = input.nextLine();
        
        while (!command.equals("exit")) {
            executeCommand(command);
            
            System.out.print(session.getUsername() + "> ");
            command = input.nextLine();
        }
        
        session.storeSession();
        System.out.println("Session saved. Exiting shell...");
        input.close();
	}
	
	/**
	 * Method to execute a command
	 * @param command - a command
	 */
	private void executeCommand(String command) {
		if(command.startsWith("ls")) {
			executeLS();
		}else if (command.startsWith("echo ")) {
            executeEcho(command);
        } else if (command.startsWith("history")) {
            if (command.trim().equals("history")) {
                showHistory();
            } else {
                int position = Integer.parseInt(command.split(" ")[1]);
                String specificCommand = showSpecificHistory(position);
                
                if (specificCommand != null) {
                    System.out.println(specificCommand);
                } else {
                    System.out.println("Invalid history number");
                }
            }
        } else {
            System.out.println("Command not recognized");
        }

        session.addCommandToHistory(command);
	}

	/**
	 * Method to list the directory content
	 * @param path - the current path
	 */
	public void executeLS() {
		//Create a File array
		File currentDir = new File(".");
		File[] filesList = currentDir.listFiles();
		
		if(isCorrectDir(currentDir)) {
			//Print actual path
			System.out.println(currentDir);
			
			//Return list of directories and files
			filesList = currentDir.listFiles();
			
			//Print the files list
			for(File currFile:filesList) {
				String type = currFile.isDirectory()?"d":"-";
				
				System.out.println(type+getPermissions(currFile)+" "+currFile.getName());
			}
		}else {
			System.out.println("Cannot be listed");
		}
	}
	
	/**
	 * Method to get the permissions.
	 * @param file - the current file
	 * @return - A permissions string
	 */
	private String getPermissions(File file) {
		String perm="";
		
		if(file.canRead()) {perm += "r";}
		
		if(file.canWrite()) {perm += "w";}
		
		if(file.canExecute()) {perm += "x";}
		
		return perm;
	}
	
	/**
	 * Method to check the path
	 * @param path - the user path
	 * @return - true if the path is correct
	 */
	private boolean isCorrectDir(File path) {
		//Path check
		if(path.exists()) {
			
			if(path.isDirectory()) {
				return true;
			}else {
				System.out.println("Is a file.");
				return false;
			}
		}else {
			System.out.println("Error! Path not found.");
			return false;
		}
	}
	
	/**
	 * Execute echo method
	 * @param command - the user command
	 */
	private void executeEcho(String command) {
        String[] parts = command.split(">");
        if (parts.length < 2) {
            System.out.println("Invalid echo command format");
        } else {
            String text = parts[0].substring(5).trim();
            String fileName = parts[1].trim();
            writeTextToFile(text, fileName);
        }
    }
	
	/**
	 * Method to write text to file
	 * @param text - the content text
	 * @param fileName - the file name
	 */
    private void writeTextToFile(String text, String fileName) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(fileName, true))) {
            writer.println(text);
            System.out.println("Text written to " + fileName);
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }
	
	/**
	 * Show history method
	 */
	private void showHistory() {
		for (String command : session.getCommandHistory()) {
            System.out.println(command);
        }
	}
	
	/**
	 * Show specific command history
	 * @param n - the command position
	 */
	private String showSpecificHistory(int n) {
		String specificCommand = null;
        try (RandomAccessFile file = new RandomAccessFile(session.getHistoryFile(), "r")) {
            if (n < session.getCommandHistory().size()) {
                file.seek(0); // Reset file pointer
                
                for (int i = 0; i <= n; i++) {
                    specificCommand = file.readLine();
                }
            }
        } catch (IOException e) {
            System.err.println("ERROR: "+e.getMessage());
        }
        return specificCommand;
    }
	
}
