package shell;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Session class
 * @author Yarii Soto
 * @version v1, 4 November 2023
 */
public class Session implements Serializable{
	private static final long serialVersionUID = 1L;
	private String username;
	private LocalDateTime startTime;
	private LocalDateTime endTime;
	private String historyFile;
	private List<String>  commandHistory;
	
	/**
	 * Session constructor
	 * @param username - an User name
	 */
	public Session(String username) {
		this.username = username;
		this.startTime = LocalDateTime.now();
        this.endTime = null;
        this.historyFile = username + ".hist";
        this.commandHistory = new ArrayList<>();
        
        loadSession();
	}
	
	/**
	 * Load session
	 */
	private void loadSession() {
		File sessionFile = new File(username + ".sess");
        
		if (sessionFile.exists()) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(sessionFile))) {
                Session savedSession = (Session) ois.readObject();
                this.startTime = savedSession.startTime;
                this.endTime = savedSession.endTime;
                this.commandHistory = savedSession.commandHistory;
                this.historyFile = savedSession.historyFile;
            } catch (IOException | ClassNotFoundException e) {
            	System.err.println("ERROR: "+e.getMessage());
            }
        }
    }
    
    /**
     * Store Session object
     */
    public void storeSession() {
    	this.endTime = LocalDateTime.now();
    	
    	//Write the session object
		try (ObjectOutputStream writer = new ObjectOutputStream(new FileOutputStream(this.username+".sess"))) {
			writer.writeObject(this);
			
		} catch (IOException e) {
			System.err.println("ERROR: "+e.getMessage());
		}
		
		//Write the commandHistory file
		try (BufferedWriter writer = new BufferedWriter(new FileWriter(historyFile))) {
            for (String command : commandHistory) {
                writer.write(command);
                writer.newLine();
            }
        } catch (IOException e) {
        	System.err.println("ERROR: "+e.getMessage());
        }
	}
    
    /**
     * Add commands to commandHistory
     * @param command - user command
     */
    public void addCommandToHistory(String command) {
        commandHistory.add(LocalDateTime.now() + " - " + command);
    }
    
    /**
     * CommandHistory getter
     * @return - a command history list
     */
    public List<String> getCommandHistory() {
        return commandHistory;
    }

    /**
     * Username getter
     * @return the username
     */
	public String getUsername() {
		return username;
	}
	
	/**
     * historyFile getter
     * @return the username
     */
	public String getHistoryFile() {
		return historyFile;
	}
    
}
