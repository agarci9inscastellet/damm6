package shell;


import java.util.Scanner;

/*
 * Program a shell that starts asking for the username. Once the user is identified, a session object saved in the file [user].sess is loaded if it exists.
 * 
 * Thell shows the user name amd espects a command from the keyboard:
 * 
 * alex>_
 * 
 * 
 * The shell accepts three commands:
 * 
 * ls shows a listing of the current directory (no recursion required) 
 * 
 * echo txt > filename writes a text to the file filename
 * 
 * history [n] displays command history. The history is saved in a [user].hist file. The date-time and the command are recorded. If the parameter n is given it shows specifically the command at position n (use a random access file)
 * 
 * On closing, the session object is saved to the file [user].sess
 * 
 * The "session" object contains:
 * 
 * username
 * date-time start
 * end date-time
 * history file
 * */
/**
 * Shell program
 * @author Yarií Soto
 * @version v1, 13 October 2023
 */
public class shellMain {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.println("Wellcome to Yarii's shell!");
		
		System.out.print("Enter your username: ");
		String username=input.nextLine();

        Session session = new Session(username);
        Shell shell = new Shell(session);
        shell.startShell();
        
        input.close();
	}

}
