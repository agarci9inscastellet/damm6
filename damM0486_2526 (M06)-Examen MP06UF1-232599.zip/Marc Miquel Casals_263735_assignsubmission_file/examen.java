package examen;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class examen {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Usuari: ");
        String usuari = sc.nextLine();
        System.out.println("Contrasneya: ");
        String pass = sc.nextLine();

        File f = new File("users.txt");

        boolean trobat = false;

        BufferedReader br = null;


        try {
            if(f.exists()) {
                br = new BufferedReader(new FileReader(f));
                String linea;
                while((linea = br.readLine()) != null){
                    String[] parts = linea.split("#");
                    if(parts[0].equals(usuari)) {
                        trobat = true;
                        if (parts[1].equals(pass)){
                            System.out.println("Acces correcte");
                        } else {
                            System.out.println("La contrasenya no es correcte");
                            break;
                        }
                }
            }
        } catch (IOException e ) {
            System.out.println("Error"+ e.getMessage());
        } finally {
            try {
                if (br!=null) br.close();
            } catch (Exception e) {
                if(!trobat){
                    System.out.println("L'usuari no existeix, vols afegirlo al final? (s/n):");
                }
                // A partir d'aqui hem de crear un bw (BufferedWriter) i posar el usuari al fitxer
                // seria com un br.write(usuari + "#" + pass) pero no se com implementar-ho
            }
        }
        

        //exercici 3

        System.out.println("Quin producte vols editar (id): ");
        int id = sc.nextInt();
        
        //no se mostrar les dades

        System.out.println("Modifica les dades del producte. ");
        System.out.println("> Nom: ");
        String nomProducte = sc.nextLine();
        System.out.println("> Preu: ");
        Double preuProducte = sc.nextDouble();
    }

    

}
