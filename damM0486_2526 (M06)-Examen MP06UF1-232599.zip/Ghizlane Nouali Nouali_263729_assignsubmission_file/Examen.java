import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class Examen {


    public static void main(String[] args) {
        // Ex1
        ArrayList<String> llistaEx1 = new ArrayList<>();
        Scanner sc = new Scanner(System.in);

        System.out.println("Introdueix el usuari:");
        String user = sc.nextLine();

        System.out.println("Introdueix el password:");
        String pass = sc.nextLine();
        
        try (BufferedReader br = new BufferedReader(new FileReader("users.txt"))) {
            String linea;
             while ((linea = br.readLine()) != null){
                llistaEx1.add(linea);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        for (String string : llistaEx1) {

            String[]parts = string.split("#");
            System.out.println(parts[0] + parts[1] + user + pass);
            if (parts[0] == user && parts[1] == pass) {
                 System.out.println("Login Correcte");
                    break;

            } 
            if (parts[0] == user && parts[1] != pass) {
                System.out.println("Login incorrecte, torna-ho a intentar");
                    break;
            }
        }

        try(BufferedWriter bw = new BufferedWriter(new FileWriter("users.txt",true))){
            bw.write(user);
            bw.write(pass);
            bw.newLine();
            bw.close();
            System.out.println("UsuariCreat");
            
        } catch (IOException e){
            e.printStackTrace();
        }




        // // Ex2
        try (RandomAccessFile raf = new RandomAccessFile("shop.bin", "r")) {
            long tamanyArxiu = raf.length();
            long totalRegistres = tamanyArxiu / 38;
            System.out.println("# Nombre de productes: " + totalRegistres + " #\n" + "##################");
            for (int i = 0; i < totalRegistres; i++) {
                raf.seek(38 * i);
                Integer codi = raf.readInt();
                StringBuilder sb = new StringBuilder();
                for (int j = 0; j < 15; j++) {
                    sb.append(raf.readChar());
                }
                String nom = sb.toString().trim();
                Float preu = raf.readFloat();
                System.out.println("\nid: " + i + "\ncodi del producte: " + codi + "\nnom: " + nom + "\nPreu: " + preu);
            }
        } catch (Exception e) {
            // TODO: handle exception
        }



        //Ex3
        System.out.println("Introdueix la id del producte a editar");
        Integer id = sc.nextInt();

        try(RandomAccessFile raf = new RandomAccessFile("shop.bin", "rw")){
            long tamanyArxiu = raf.length();
            long totalRegistres = tamanyArxiu / 38;

            if (id > totalRegistres) {
                System.out.println("Err.La id no es valida pasa el total de registres");
                return;
            }

            for (int i = 0; i < totalRegistres; i++) {
                raf.seek((38 * i));
                if (id.equals(i)) {
                    Integer codi = raf.readInt();
                    StringBuilder sb = new StringBuilder();
                    for (int j = 0; j < 15; j++) {
                        sb.append(raf.readChar());
                    }
                    String nom = sb.toString().trim();
                    Float preu = raf.readFloat();
                    System.out.println("Nom actual: " + nom + " introdueix el nou nom:");
                    Scanner sc1 =  new Scanner(System.in);
                    String nomMod = sc1.nextLine();
                    
                    System.out.println("PreuActual: " + preu + " introdueix el nou preu:");
                    Scanner sc2 =  new Scanner(System.in);
                    Float preuMod = sc2.nextFloat();

                    raf.seek(38 * i);
                    StringBuilder sbNom = new StringBuilder(nomMod);
                    sbNom.setLength(15);

                    raf.writeInt(codi);
                    raf.writeChars(sbNom.toString());
                    raf.writeFloat(preuMod);
                    System.out.println("Dades modificades correctament!");

                    raf.seek(38 * i);
                    Integer codi2 = raf.readInt();
                    StringBuilder sb2 = new StringBuilder();
                    for (int j = 0; j < 15; j++) {
                        sb2.append(raf.readChar());
                    }
                    String nom2 = sb2.toString().trim();
                    Float preu2 = raf.readFloat();
                    System.out.println("\nid: " + i + "\ncodi del producte: " + codi2 + "\nnom: " + nom2 + "\nPreu: " + preu2);
                    guardarData(id);
                    llegirData();
                    break;
                }
            }
        } catch (IOException e){
            e.printStackTrace();
        }
     }

//     //Ex4
    public static void guardarData(Integer id) {
        LocalDate today = LocalDate.now();
        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream("log.bin",true))) {
            String linea = today.toString() + " " + id;
            dos.writeUTF(linea);

        } catch (Exception e) {
            // TODO: handle exception
        }
    }

    public static void llegirData(){
        try(DataInputStream dis = new DataInputStream(new FileInputStream("log.bin"))){
            System.out.println("Fitxer log.bin");
            while (true) {
                System.out.println(dis.readUTF());
            }
            
       } catch (EOFException e) {
        // fin
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


    
}
