import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Scanner;

public class ExamenGRuiz {

    public static void main(String[] args) {

        Scanner read = new Scanner(System.in);

        // EXERCICI 1 INTENTO FALLIDO, NO M'HA DONAT TEMPS
        /*
         * 
         * boolean exit = false;
         * 
         * String usersFile = "users.txt";
         * 
         * String usuari = "";
         * String pssw = "";
         * 
         * while (!exit) {
         * System.out.println("---------------------");
         * System.out.println("Introdueix l'usuari:");
         * usuari = read.nextLine();
         * System.out.println("Introdueix la contraseña:");
         * pssw = read.nextLine();
         * System.out.println("---------------------");
         * 
         * try {
         * BufferedReader bf = new BufferedReader(new FileReader("users.txt"));
         * 
         * } catch (Exception e) {
         * // TODO: handle exception
         * }
         * 
         * 
         * }
         */

        // EXERCICI 2 NO HE UTILIZAT EL SEEK PERO SI HO HE FET EN EL SEGUENT EXERCICI =D

        final int RECORD_SIZE = 38;
        final int NOM_SIZE = 15;
        StringBuilder out = new StringBuilder();
        try (RandomAccessFile raf = new RandomAccessFile("shop.bin", "r")) {
            long numProd = raf.length() / RECORD_SIZE;
            int codi;
            int id = 0;
            float preu;
            long posicio = 0;
            out.append("# Nombre de productes: " + numProd + "#\n");
            out.append("########################################\n");

            for (int r = 0; r < numProd; r++) {
                out.append("id: " + id + "\n");
                codi = raf.readInt();
                out.append("codi del producte: " + codi + "\n");
                StringBuilder b = new StringBuilder();
                for (int i = 0; i < NOM_SIZE; i++) {
                    b.append(raf.readChar());
                }
                String nom = b.toString().replace('\0', ' ').trim();
                out.append("nom: " + nom + "\n");
                preu = raf.readFloat();
                out.append("preu: " + preu + "\n");
                out.append("---------------------------\n");
                id++;
            }
            System.out.println(out);
        } catch (FileNotFoundException e) {

            e.printStackTrace();
        } catch (IOException e) {

            e.printStackTrace();
        }

        // EXERCICI 3
        int id;
        System.out.println("Quin producte vols editar? (id)");
        id = read.nextInt();
        float preu;
        int codi;
        StringBuilder outEx3 = new StringBuilder();
        long desplaçament = (long) id * RECORD_SIZE;

        try (RandomAccessFile raf = new RandomAccessFile("shop.bin", "rw")) {
            raf.seek(desplaçament);
            outEx3.append("Producte a modificar: \n");
            outEx3.append("---------------------------\n");
            outEx3.append("id: " + id + "\n");
            codi = raf.readInt();
            outEx3.append("codi del producte: " + codi + "\n");
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < NOM_SIZE; i++) {
                b.append(raf.readChar());
            }
            String nom = b.toString().replace('\0', ' ').trim();
            outEx3.append("nom: " + nom + "\n");
            preu = raf.readFloat();
            outEx3.append("preu: " + preu + "\n");
            outEx3.append("---------------------------\n");
            System.out.println(outEx3);
            read.nextLine();
            System.out.println("Indica el nou nom: ");
            nom = read.nextLine();
            System.out.println("Indica el nou preu: ");
            preu = read.nextFloat();

            raf.seek(desplaçament);
            raf.readInt();
            StringBuilder sbNom = new StringBuilder(nom);
            sbNom.setLength(15);
            raf.writeChars(sbNom.toString());
            raf.writeFloat(preu);
            System.out.println("----------------------");
            System.out.println("Registre actualitzat: ");

            StringBuilder actualitzat = new StringBuilder();
            long numProd = raf.length() / RECORD_SIZE;
            raf.seek(0);
            for (int r = 0; r < numProd; r++) {
                actualitzat.append("id: " + id + "\n");
                codi = raf.readInt();
                actualitzat.append("codi del producte: " + codi + "\n");
                StringBuilder c = new StringBuilder();
                for (int i = 0; i < NOM_SIZE; i++) {
                    c.append(raf.readChar());
                }
                nom = c.toString().replace('\0', ' ').trim();
                actualitzat.append("nom: " + nom + "\n");
                preu = raf.readFloat();
                actualitzat.append("preu: " + preu + "\n");
                actualitzat.append("---------------------------\n");
                id++;
            }

            System.out.println(actualitzat);

        } catch (FileNotFoundException e) {

            e.printStackTrace();
        } catch (IOException e) {

            e.printStackTrace();
        }

    }
}
