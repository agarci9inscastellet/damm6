
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.RandomAccesFile;

public class Examenuf1_JosueGonzalez {

    public static void main(String[] args) throws FileNotFoundException {
                // definim variables i obrim scanner per guardar respostes de l'usuari
        String file = "users.txt";
        boolean login = false;

        Scanner sc = new Scanner(System.in);

        // llegim el fitxer linia a linia, separant per cada linia el nom i la contrasenya i comparem si son iguals
        FileReader fr = new FileReader(file);
        BufferedReader br = new BufferedReader(fr);
        while ((br.readLine()) != null) {
            String username = "";
            String password = "";
            System.out.println("Entra el nom: ");
            String newusername = sc.nextLine();

            System.out.println("Entra la contrasenya: ");
            String newpassword = sc.nextLine();

            if (username.split("#")[0].equals(newusername)) {
                password = username.split("#")[1];
                if (password.equals(newpassword)) {
                    System.out.println("Login correcte");
                    login = true;
                    break;
                } else {
                    System.out.println("Login incorrecte");
                    continue;
                }
            }

            if (!username.split("#")[0].equals(newusername)) {
                FileWriter fw = new FileWriter(file);
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write(username + "#" + password);
                bw.newLine();
                bw.close();

            }
        }
        br.close();

        if (login) {

            RandomAccesFile raf = new RandomAccessFile("shop.bin");

            int registre = 38;
            int numRegistres;
            //aqui no men recordo de com es feia per legir byte a byte...
            //pero s'ha de fer un bucle fins que doni -1 (que vol dir que no hi ha cap registre), 
            //despres guardar els 4 primers bytes com a int, els 30 seguents com a nom i els 4 restants com a preu.
           // se que era raf.seek(pos).
           //raf.readChar(); i raf.writeInt();
        // als 38 torna a legir i torna a guardar com a segon producte, als 38 el seguent i aixi fins que et dona el -1 del bucle
        //no recordo com es feia servir el seek i m'he fet una xuleta de merda....
        //guardariem tambe la posicio del  byte del producte per despres al seguent exercici poderlo guardar al mateix lloc

        System.out.print("posa l'id del producte que vulguis editar");

         try (DataInputStream dos = new DataInputStream(new FileInputStream("data.bin"))) {
			
			            for (int i = 0; i < (numero de registres de  lexercici anterior); i++) {
			                int codiBuscat = sc.nextInt();
                            int codi = dis.readInt();
                            int nom = Aqui em passa el mteix que necessito lo de l'exercici anterior.
                            int preu = aqui passsa el mateix que ho necessito de l'exercici anterior.
                            int posicio= 0;
			                if (codi == codiBuscat) {
			               system.out.print("vols modificar el nom? (s/n)");
                           char opcio = sc.nextLine();
                           if (opcio.equals(s)) {
                            system.out.print("Entra el nou nom"); 
                                string nouNom = sc.nextLine();
                            
                                system.out.print("vols modificar el preu? (s/n)");
                           char opcio2 = sc.nextLine();
                           if (opcio.equals(s)) {
                            system.out.print("Entra el nou preu"); 
                                string nouPreu = sc.nextLine();
                            
                           } 
                           
                           //ara buscaria la posicio on estava i borraria els 38 bytes i despres guardaria el producte modificat a la posicio.

                           //amb el raf.seek(posicio)
                           } 

			        //i el ultim exercici ni tel faig... em sap greu no he estudiat gens perque tinc el cap a altres llocs ara mateix.




            }

        

        }

}
