package m6;

import java.io.*;
import java.util.*;

public class Formulari {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		File f = new File("users.txt");
		String[] registre = new String[100];

		try {
			BufferedReader br = new BufferedReader(new FileReader(f));
			registre=br.readLine().split("#");

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(String str:registre) {
			System.out.println(str);
		}


		//llegir
		try {
			DataInputStream dt = new DataInputStream(new FileInputStream(f));
			boolean findUser=false;
			boolean findPass=false;


			String userBuscar=demanarUser(sc).concat("#");
			String passBuscar=demanarContra(sc);

			while(!findUser && !findPass) {
				//llegir registre
				String user=dt.readUTF();
				
				String pass=dt.readUTF();
				System.out.println(user + pass);
				if(userBuscar.equals(user)){
					findUser=true;
				}else {
					System.out.println("USUSARI NO TROBAT");
				}
				if(passBuscar.equals(pass)) {
					findPass=true;
					
				}else {
					System.out.println("PASSWORD INCORRECTE, torna a intentar.");

					registre(sc);
					break;
				}

				if(findUser && findPass) {
					System.out.println("LOGIN CORRECTE");
					break;
				}
				

			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void registre(Scanner sc) {
		//escriure
		try {

			DataOutputStream dto = new DataOutputStream(new FileOutputStream("users.txt"));
			StringBuilder sb = new StringBuilder();
			StringBuilder pss = new StringBuilder();
			sb.append(demanarUser(sc));
			sb.append("#");
			dto.writeUTF(sb.toString());


			pss.append(demanarContra(sc));
			dto.writeUTF(pss.toString());
			//es demana y escriu el usuari

			System.out.println("USUSARI CREAT");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static String demanarUser(Scanner sc) {
		String user;
		System.out.println("Introdueix nom user:");
		user=sc.nextLine();
		return user;
	}
	public static String demanarContra(Scanner sc) {
		String pass;
		System.out.println("Introdueix contrasenya:");
		pass=sc.nextLine();
		return pass;
	}
}
