import java.io.*;
import java.util.Scanner;
import java.time.*;

public class Examenuf1_PolPlanas {

    static final int MIDA_CODI = 4;
    static final int MIDA_NOM = 30;
    static final int MIDA_PREU = 4;
    static final int MIDA_REGISTRE = 38;

    public static void main(String[] args) {
        boolean logined = false;

        if (!logined) {
            login(logined);
        }
    }

    public static void productes() {
        try (RandomAccessFile raf = new RandomAccessFile("shop.bin", "r")) {
            int tamany = (int) raf.length();
            int registres = (tamany / 38);

            raf.seek(0);

            int codi = raf.readInt();
            String nom = raf.toString();
            double preu = raf.readDouble();

            System.out.println("\nRegistre: ");
            System.out.println("Codi: " + codi);
            System.out.println("Nom: " + nom);
            System.out.println("Preu: " + preu);         

        } catch (IOException e){
            System.out.println("Els registres no s'han trobat.");
        }
    }

    public static void login(boolean logined) {
        Scanner in = new Scanner(System.in);

        try (BufferedReader reader = new BufferedReader(new FileReader("users.txt"))) {
            
            String line;
            while ((line = reader.readLine()) != null) {

                System.out.print("Usuari: ");
                String usuari = in.nextLine();

                System.out.print("Contrasenya: ");
                String pass = in.nextLine();

                if (line.contains(usuari)) {
                    if (pass.equals(line.substring(usuari.length() +1))) {
                        System.out.println("Login Correcte!");
                        logined = true;
                        productes();
                        break;
                    } else {
                        System.out.println("Login incorrecte, torna-ho a intentar.");
                    }
                } else {
                    FileOutputStream fos = new FileOutputStream("users.txt");
                    OutputStreamWriter writer = new OutputStreamWriter(fos);

                    writer.write(usuari + "#" + pass);

                    System.out.print("Usuari Creat");

                    fos.close();

                    login(logined);
                }
                reader.close();
            }
        } catch (IOException e){
            System.out.println("El document no s'ha trobat");
        }
    }

    public static String dataActual() {
        LocalDate today = LocalDate.now();
        return today.toString();
    }

    public static void register() {
        try (DataInputStream dis = new DataInputStream(new FileInputStream("log.bin"))) {
            dis.writeChars(dataActual().toString());
        } catch (IOException e) {

        }
    }
}
