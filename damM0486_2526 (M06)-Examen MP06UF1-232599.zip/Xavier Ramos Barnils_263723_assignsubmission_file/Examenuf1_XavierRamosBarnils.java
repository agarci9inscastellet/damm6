import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Scanner;

public class Examenuf1_XavierRamosBarnils {
    private static String userFileName = "users.txt";
    private static String shopFileName = "shop.bin";
    private static long BYTE_LENGTH = 38;
    public static void main(String[] args) {
        String user;
        String password;
        Scanner sc = new Scanner(System.in);
        System.out.print("Escriu el nom d'usuari: ");
        user = sc.next();
        System.out.print("Escriu la contrasenya: ");
        password = sc.next();
        logIn(user,password);

        mostrarLlista();
        sc.close();
    }

    private static void mostrarLlista() {
        String line;
        try {
            RandomAccessFile raf = new RandomAccessFile(shopFileName, "r");
            System.out.println("# Nombre de productes: " + raf.length()/BYTE_LENGTH + " #");
            for (int i = 0; i < raf.length()/BYTE_LENGTH; i++) {
                raf.seek(i*(BYTE_LENGTH));
                line = raf.readLine();
                System.out.println(line);               
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    }

    private static void logIn(String user, String password) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(userFileName));           
            String userData = "";
            while ((userData = br.readLine()) != null) {
                if (userData.contains(user)) {
                    if (userData.equals(user+"#"+password) || userData.equals(user+"#"+password+"\n")) {
                        System.out.println("Has accedit correctament");
                    } else {
                        System.out.println("La contrasenya no és correcte");
                    }                  
                } else {
                    BufferedWriter bw = new BufferedWriter(new FileWriter(userFileName, true));
                    bw.append(user+"#"+password+"\n");
                    bw.close();
                }
            }
            br.close();                         
        } catch (IOException e) {
            e.printStackTrace();
        }        
    }
}
